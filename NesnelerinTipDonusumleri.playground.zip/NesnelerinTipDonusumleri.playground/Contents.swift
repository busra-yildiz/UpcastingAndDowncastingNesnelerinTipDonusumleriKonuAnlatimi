import UIKit

//Upcasting: Alt class üst classa dönecek yani saray eve dönecek olarak düşünebiliriz.

var ev = Saray(kuleSayisi: 3, pencereSayisi: 10) as Ev



//Downcasting: Üst class alt classa dönecek.

var Saray = Ev(pencereSayisi: 6) as? Saray



//Tip kontrolü: örneğin bu nesne evden mi türedi gibi kontrolleri sağlar.
if ev is Ev {
    print ("Nesne ev sınıfındadır")
}
else {
    print ("Nesne ev sınıfında değildir")
}
